﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Payrol
{
    public partial class ForgotPassword : Form
    {
        public ForgotPassword()
        {
            InitializeComponent();
        }

        private void ForgotPassword_Load(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (txtEmail.Text == "" && txtNo.Text == "")
            {
                MessageBox.Show("Please fill in your email and cellphone number to log in!", "Missing information");
            }
            else
            {
                try
                {
                    string userId = txtEmail.Text;
                    string userName = txtNo.Text;
                    bool user = false;

                    using (StreamReader reader = new StreamReader(@"C:\Users\nrobe\OneDrive\Desktop\A - App Clients Project\Database Register.txt"))
                    {
                        string line;
                        while ((line = reader.ReadLine()) != null)
                        {
                            string[] fields = line.Split('\t');
                            if (fields[5] == userId && fields[2] == userName)
                            {
                                user = true;
                                break;
                            }
                        }
                        if (user)
                        {
                            MessageBox.Show("Welcome back", "Sucessful Login");
                            new Payroll().Show();
                            this.Hide();
                        }
                        else
                        {
                            MessageBox.Show("Please input correct information", "Invalid login!");
                            new LogIn().Show();
                            this.Hide();
                        }
                    }
                }
                catch (FileNotFoundException)
                {
                    MessageBox.Show("UsersInfo.txt not found!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"An error occurred: {ex.Message}");
                }
            }
        }
    }
}
