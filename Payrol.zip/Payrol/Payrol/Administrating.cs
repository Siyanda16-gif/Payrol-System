﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Payrol
{
    public partial class Administrating : Form
    {
        public Administrating()
        {
            InitializeComponent();
        }

        public static bool IsNumeric(string text)
        {
            foreach (char c in text)
            {
                if (!char.IsDigit(c))
                {
                    return false;
                }
            }
            return true;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if ((txtName.Text == "") && (txtCell.Text == ""))
            {
                MessageBox.Show("Please input the details of the employee you're looking for.", "Missing information!");
            }
            else
            {
                int cnumber;
                if (IsNumeric(txtCell.Text))
                {
                    cnumber = int.Parse(txtCell.Text);
                    if (txtCell.Text.Length == 10)
                    {
                        cnumber = int.Parse(txtCell.Text);
                    }
                    else
                    {
                        MessageBox.Show("Please entera valid cellphone number");
                    }
                }
                else
                {
                    MessageBox.Show("You can't input a letter/word in your cellphone number!", "Invalid input");
                }

                string gross = "", Deduct = "", Incent = "", Net = "", uif = "", vat = "";
                string permission = "";
                string name, no;
                name = txtName.Text;
                no = txtCell.Text;
                string line = "";
                string[] la = new string[8];
                bool user = false;

                StreamReader obj = new StreamReader(@"C:\Users\nrobe\OneDrive\Desktop\A - App Clients Project\Database Register.txt");
                using (obj)
                {
                    line = obj.ReadLine();
                    while (line != null)
                    {
                        la = line.Split('\t');
                        if ((name == la[0]) && (no == la[6]))
                        {
                            user = true;
                            break;

                        }
                        line = obj.ReadLine();
                    }
                    if (user)
                    {
                        lblRegInfo.Text = "Name: " + '\t'+ la[0] + "\n" + "Surname: " + '\t' + la[1] + "\n" + "Username: " + '\t' + la[2] + "\n" + "Password: " + '\t' + la[3] + "\n" + "Confirm password: " + '\t' + la[4] + "\n" + "Email: " + '\t' + la[5] + "\n" + "Cellphone number: " + '\t' + la[6] + "\n" + "Gender: " + '\t' + la[7] + '\n';

                        //Booking info code:
                        string temp = "";
                        string lineRec1 = "";
                        string[] lineArray1 = new string[7];
                        bool found = false;
                        StreamReader send = new StreamReader(@"C:\Users\nrobe\OneDrive\Desktop\A - App Clients Project\CostDatabase.txt");
                        using (send)
                        {
                            lineRec1 = send.ReadLine();
                            while (lineRec1 != null)
                            {
                                lineArray1 = lineRec1.Split('\t');
                                if (lineArray1[0] == name)
                                {
                                    found = true;
                                    break;
                                }

                                lineRec1 = send.ReadLine();
                            }
                        }
                        if (found)
                        {
                            gross = lineArray1[1];
                            Deduct = lineArray1[4];
                            Incent = lineArray1[6];
                            Net = lineArray1[5];
                            vat = lineArray1[2];
                            uif = lineArray1[3];
                        }

                        lblInfo.Text = "Gross Salary: " + '\t' + "R" + lineArray1[1] + "\n" + "Incentive Amount: " + '\t' + "R" + lineArray1[6] + "\n" + "Deduction Amount: " + '\t' + "R" + lineArray1[4] + "\n" + "VAT Amount: " + '\t' + "R" + lineArray1[2] + "\n" + "UIF Amount: " + '\t' + "R" + lineArray1[3] + "\n" + "Net Gross: " + '\t' + "R" + lineArray1[5] + "\n";
                    }
                    else
                    {
                        MessageBox.Show("The person you're looking for is not registered to our system!", "Person not found!!!");

                    }
                }
            }
        }

        private void btnReg_Click(object sender, EventArgs e)
        {
            try
            {
                Process.Start(@"C:\Users\nrobe\OneDrive\Desktop\A - App Clients Project\Database Register.txt");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error opening Notepad: " + ex.Message);
            }
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            new Form1().Show();
            this.Hide();
        }
    }
}
