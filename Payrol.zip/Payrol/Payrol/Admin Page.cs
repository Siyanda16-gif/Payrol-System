﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Payrol
{
    public partial class Admin_Page : Form
    {
        public Admin_Page()
        {
            InitializeComponent();
        }

        private void Admin_Page_Load(object sender, EventArgs e)
        {

        }
        
        private void btnLogin_Click(object sender, EventArgs e)
        {
            string name, password;
            name = txtName.Text;
            password = txtPass.Text;
            if ((name == "") || (password == ""))
            {
                MessageBox.Show("Please fill in admin name and password!", "Missing Information");
            }
            else
            {
                if ((name == "Ziyanda") && (password == "Admin123"))
                {
                    MessageBox.Show("Welcome back " + name, "Sucessful Login!");
                    new Administrating().Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Make sure information typed in is correct!", "Invalid login");
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            new Form1().Show();
            this.Hide();
        }

        private void chkPass_CheckedChanged(object sender, EventArgs e)
        {
            if (chkPass.Checked)
            {
                txtPass.PasswordChar = '\0';
            }
            else
            {
                txtPass.PasswordChar = '*';
            }
        }
    }
}
