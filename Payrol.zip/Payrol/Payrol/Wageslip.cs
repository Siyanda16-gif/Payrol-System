﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Payrol
{
    public partial class Wageslip : Form
    {
        public Wageslip()
        {
            InitializeComponent();
        }

        private void Wageslip_Load(object sender, EventArgs e)
        {
            string id = "";
            string li = "";
            string[] ar = new string[1];
            StreamReader cs = new StreamReader(@"C:\Users\nrobe\OneDrive\Desktop\A - App Clients Project\Temp Database.txt");
            using (cs)
            {
                li = cs.ReadLine();
                ar = li.Split('\t');
                id = ar[0];
            }

            string temp = "";
            string lineRec1 = "";
            string[] lineArray1 = new string[7];
            bool found = false;
            StreamReader send = new StreamReader(@"C:\Users\nrobe\OneDrive\Desktop\A - App Clients Project\CostDatabase.txt");
            using (send)
            {
                lineRec1 = send.ReadLine();
                while (lineRec1 != null)
                {
                    lineArray1 = lineRec1.Split('\t');
                    if (lineArray1[0] == id)
                    {
                        found = true;
                        break;
                    }

                    lineRec1 = send.ReadLine();
                }
                if (found)
                {
                    lblDeductionAmt.Text = "R" +  lineArray1[4];
                    lblDeduction.Text = "R" + lineArray1[4];
                    lblGross.Text = "R" + lineArray1[1];
                    lblGrossAmt.Text = "R" + lineArray1[1];
                    lblGrossSalary.Text = "R" + lineArray1[1];
                    lblIncent.Text = "R" + lineArray1[6];
                    lblNet.Text = "R" + lineArray1[5];
                    lblTax.Text = "R" + lineArray1[2];
                    lblUIF.Text = "R" + lineArray1[3];
                }
                else
                {
                    MessageBox.Show("Record cannot be found!", "Database error");
                }
            }

            //StreamReader share = new StreamReader(@"C:\Users\nrobe\OneDrive\Desktop\A - App Clients Project\CostDatabase.txt");
            //using (share)
            //{
            //    lineRec1 = send.ReadLine();
            //    while (lineRec1 != null)
            //    {
            //        lineArray1 = lineRec1.Split('\t');
            //        if (lineArray1[0] == id)
            //        {
            //            found = true;
            //            break;
            //        }

            //        lineRec1 = send.ReadLine();
            //    }
            //    if (found)
            //    {
            //        lblDeductionAmt.Text = lineArray1[4];
            //        lblDeduction.Text = lineArray1[4];
            //        lblGross.Text = lineArray1[1];
            //        lblGrossAmt.Text = lineArray1[1];
            //        lblNet.Text = lineArray1[5];
            //        lblTax.Text = lineArray1[2];
            //        lblUIF.Text = lineArray1[3];
            //    }
            //    else
            //    {
            //        MessageBox.Show("Record cannot be found!", "Database error");
            //    }
            //}
        }

        private void btnMove_Click(object sender, EventArgs e)
        {
            new Form1().Show();
            this.Hide();
        }
    }
}
