﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Payrol
{
    public partial class LogIn : Form
    {
        public LogIn()
        {
            InitializeComponent();
        }

        private void LogIn_Load(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if ((txtName.Text == "") && (txtPass.Text == ""))
            {
                MessageBox.Show("Please fill in your details so you could login.", "Missing information!!!");
            }
            else
            {
                string username = txtName.Text;
                string password = txtPass.Text;

                bool userFound = false;

                using (StreamReader sr = new StreamReader(@"C:\Users\nrobe\OneDrive\Desktop\A - App Clients Project\Database Register.txt"))
                {
                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        string[] userInfo = line.Split('\t');
                        if (userInfo[2] == username && userInfo[3] == password)
                        {
                            userFound = true;
                            break;
                        }
                    }
                }

                if (userFound)
                {
                    MessageBox.Show("Welcome back " + username, "Sucessful Login");
                    new Payroll().Show();
                    this.Hide();
                    string name = "";
                    string lineRec = "";
                    string[] lineArray = new string[9];
                    bool user = false;

                    StreamReader fil = new StreamReader(@"C:\Users\nrobe\OneDrive\Desktop\App Dev Project(Codes)\Database Register.txt");
                    using (fil)
                    {
                        lineRec = fil.ReadLine();
                        while (lineRec != null)
                        {
                            lineArray = lineRec.Split('\t');
                            if (username == lineArray[2])
                            {
                                user = true;
                                break;
                            }
                            lineRec = fil.ReadLine();
                        }
                        if (user)
                        {
                            name = lineArray[0];
                        }
                        else
                        {
                            MessageBox.Show("Khona inkinga boi", "Failure");
                        }
                    }
                    StreamWriter file = new StreamWriter(@"C:\Users\nrobe\OneDrive\Desktop\A - App Clients Project\Temp Database.txt");
                    using (file)
                    {
                        file.WriteLine(name);
                    }
                }
                else
                {
                    MessageBox.Show("Please input correct information", "Invalid login!");
                    new LogIn().Show();
                    this.Hide();
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            new ForgotPassword().Show();
            this.Hide();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            new Form1().Show();
            this.Hide();
        }

        private void chkPass_CheckedChanged(object sender, EventArgs e)
        {
            if (chkPass.Checked)
            {
                txtPass.PasswordChar = '\0';
            }
            else
            {
                txtPass.PasswordChar = '*';
            }
        }
    }
}
