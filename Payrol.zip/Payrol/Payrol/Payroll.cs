﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Payrol
{
    public partial class Payroll : Form
    {
        public Payroll()
        {
            InitializeComponent();
        }
        private bool _isFirstButtonClicked = false;

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            _isFirstButtonClicked = true;
            btnCheckout.Enabled = true;

            if((txtDay.Text == "") && (txtHour.Text == "") && (txtOvertime.Text == "") && (txtWork.Text == ""))
            {
                MessageBox.Show("Please fill in the missing details!", "Invalid input");
                lblH.Visible = true;
                lblN.Visible = true;
                lblO.Visible = true;
                lblR.Visible = true;
            }
            else
            {
                string id = "";
                string line = "";
                string[] array = new string[1];
                StreamReader cs = new StreamReader(@"C:\Users\nrobe\OneDrive\Desktop\A - App Clients Project\Temp Database.txt");
                using (cs)
                {
                    line = cs.ReadLine();
                    array = line.Split('\t');
                    id = array[0];
                }

                string tday = txtDay.Text;
                string thour = txtHour.Text;
                string tover = txtOvertime.Text;
                string twork = txtWork.Text;

                double day = double.Parse(tday);
                double hour = double.Parse(thour);
                double over = double.Parse(tover);
                double work = double.Parse(twork);
                double basic = 0;
                double overtime = 0;
                double salary = 0;
                double incentive = 0;
                double tax = 0;
                double uif = 0;
                double deduct = 0;
                double total = 0;

                if (chkGood.Checked)
                {
                    incentive = 1000;
                }
                else
                {
                    incentive = 0;
                }

                basic = (day * hour) * work;
                overtime = 100 * over;

                salary = basic + overtime + incentive;
                tax = salary * 0.15;
                uif = salary * 0.02;
                deduct = tax + uif;
                total = salary - deduct;

                lblGross.Text = salary.ToString("C");
                lblTax.Text = tax.ToString("C");
                lblUIF.Text = uif.ToString("C");
                lblDeduction.Text = deduct.ToString("C");
                lblDeductionAmt.Text = deduct.ToString("C");
                lblGrossSalary.Text = salary.ToString("C");
                lblNet.Text = total.ToString("C");

                StreamWriter send = new StreamWriter(@"C:\Users\nrobe\OneDrive\Desktop\A - App Clients Project\CostDatabase.txt", true);
                using (send)
                {
                    send.WriteLine(id + '\t' + salary + '\t' + tax + '\t' + uif + '\t' + deduct + '\t' + total + '\t' + incentive);
                }

                //StreamWriter cost = new StreamWriter(@"C:\Users\nrobe\OneDrive\Desktop\A - App Clients Project\Cost.txt", true);
                //using (cost)
                //{
                //    cost.WriteLine(id + '\t' + deduct + '\t' + total + '\t' + incentive);
                //}
            }
        }

        private void btnCheckout_Click(object sender, EventArgs e)
        {
            if (!_isFirstButtonClicked)
            {
                MessageBox.Show("Please click on the calculate button first to calculate and see total cost of your purchase!", "Processing error");
            }
            else
            {
                new Wageslip().Show();
                this.Hide();
            }
        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void Payroll_Load(object sender, EventArgs e)
        {
            lblH.Visible = false;
            lblN.Visible = false;
            lblO.Visible = false;
            lblR.Visible = false;
        }
    }
}
