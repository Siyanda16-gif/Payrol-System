﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Payrol
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private bool isValidName(string cname)
        {
            Regex regex = new Regex(@"^[a-zA-Z+$]");
            return regex.IsMatch(cname);
        }
        private bool ValidName(string sname)
        {
            Regex regex = new Regex(@"^[a-zA-Z+$]");
            return regex.IsMatch(sname);
        }

        private bool IsStrongPassword(string password)
        {
            if (password == null)
            {
                return false;
            }

            if (password.Length < 8)
            {
                return false;
            }

            bool upperCase = false;
            bool lowerCase = false;
            bool isDigit = false;

            foreach (char c in password)
            {
                if (Char.IsUpper(c))
                {
                    upperCase = true;
                }
                else if (Char.IsLower(c))
                {
                    lowerCase = true;
                }
                else if (Char.IsDigit(c))
                {
                    isDigit = true;
                }

                if (upperCase && lowerCase && isDigit)
                {
                    return true;
                }
            }

            return false;
        }


        public static bool IsNumeric(string text)
        {
            foreach (char c in text)
            {
                if (!char.IsDigit(c))
                {
                    return false;
                }
            }
            return true;
        }

        private void chkPass_CheckedChanged_1(object sender, EventArgs e)
        {
            if (chkPass.Checked)
            {
                txtPass.PasswordChar = '\0';
                txtCon.PasswordChar = '\0';
            }
            else
            {
                txtPass.PasswordChar = '*';
                txtCon.PasswordChar = '*';
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            lblName.Visible = false;
            lblLastN.Visible = false;
            lblEmail.Visible = false;
            lblGender.Visible = false;
            lblPass.Visible = false;
            lblConfirmPass.Visible = false;
            lblUserN.Visible = false;
            lblContact.Visible = false;
        }

        private void btnRegister_Click_1(object sender, EventArgs e)
        {
            string name, surname, username, pass, conPass, email, gender;
            int cNumber = 0, no = 0;

            name = txtName.Text;
            surname = txtSurname.Text;
            username = txtUsername.Text;
            pass = txtPass.Text;
            conPass = txtCon.Text;
            email = txtEmail.Text;
            if ((txtCon.Text == "") && (txtName.Text == "") && (txtEmail.Text == "") && (txtPass.Text == "") && (txtNo.Text == "") && (txtUsername.Text == ""))
            {
                lblName.Visible = true;
                lblLastN.Visible = true;
                lblEmail.Visible = true;
                lblGender.Visible = true;
                lblPass.Visible = true;
                lblConfirmPass.Visible = true;
                lblUserN.Visible = true;
                lblContact.Visible = true;
            }
            else
            {
                if (txtNo.Text == "")
                {
                    lblContact.Visible = true;
                    MessageBox.Show("Please input your number!");
                }
                else
                {
                    if (IsNumeric(txtNo.Text))
                    {
                        cNumber = int.Parse(txtNo.Text);
                    }
                    else
                    {
                        MessageBox.Show("You can't input a letter/word in your cellphone number!", "Invalid input");
                    }
                }
            }

            if (radMale.Checked)
            {
                gender = "Male";
            }
            else if (radFemale.Checked)
            {
                gender = "Female";
            }
            else
            {
                gender = "Other";
            }

            StreamWriter file = new StreamWriter(@"C:\Users\nrobe\OneDrive\Desktop\A - App Clients Project\Database Register.txt", true);
            using (file)
            {
                if (isValidName(name) && ValidName(surname))
                {
                    if (txtNo.Text.Length == 10)
                    {
                        if (txtEmail.Text.Contains("@"))
                        {
                            if ((username == "") && (pass == "") && (conPass == ""))
                            {
                                lblUserN.Visible = true;
                                lblPass.Visible = true;
                                lblConfirmPass.Visible = true;
                                MessageBox.Show("Please input username, password and confirm passsword", "Missing information");
                            }
                            else
                            {
                                string password = pass;
                                if (IsStrongPassword(password))
                                {
                                    if ((radFemale.Checked) || (radMale.Checked) || (radOther.Checked))
                                    {
                                        if (pass == conPass)
                                        {
                                            file.WriteLine(name + '\t' + surname + '\t' + username + '\t' + pass + '\t' + conPass + '\t' + email + '\t' + 0 + cNumber + '\t' + gender);
                                            MessageBox.Show("Your information has been successfully saved on our database", "Registration Successful " + name);
                                            new LogIn().Show();
                                            this.Hide();
                                        }
                                        else
                                        {
                                            lblPass.Visible = true;
                                            lblConfirmPass.Visible = true;
                                            MessageBox.Show("Password doesn't match", "Invalid password");
                                        }
                                    }
                                    else
                                    {
                                        lblGender.Visible = true;
                                        MessageBox.Show("Please choose one gender", "Missing information");
                                    }
                                }
                                else
                                {
                                    lblPass.Visible = true;
                                    lblConfirmPass.Visible = true;
                                    MessageBox.Show("Password is too weak. It must contain at least 8 characters, one uppercase letter, one lowercase letter, and one number.");
                                }

                            }
                        }
                        else
                        {
                            lblEmail.Visible = true;
                            MessageBox.Show("Please input valid email address");
                        }
                    }
                    else
                    {
                        lblContact.Visible = true;
                        MessageBox.Show("Please input valid number!!!");
                    }
                }
                else
                {
                    lblName.Visible = true;
                    lblLastN.Visible = true;
                    MessageBox.Show("Invalid name and surname", "Invalid Name or Surname");
                }
            }
        }

        private void chkPass_CheckedChanged_2(object sender, EventArgs e)
        {
            if (chkPass.Checked)
            {
                txtPass.PasswordChar = '\0';
                txtCon.PasswordChar = '\0';
            }
            else
            {
                txtPass.PasswordChar = '*';
                txtCon.PasswordChar = '*';
            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            new LogIn().Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            new Admin_Page().Show();
            this.Hide();
        }
    }
}
